import os

## short
os.chdir("/home/grad16/sakumar/CIKM_Experiments_2021/GaussianSV")
topics=[str(i) for i in range(10,60,10)]
datasets = ['bbc','searchsnippet','wos']
dtype='short'
# samples=5
no_of_runs = 5

for dataset in datasets:
  for num_topic in topics:
      for r in range(no_of_runs):
        os.system("perl gaussiansv.pl \
      --data ./input_data/"+dataset+"/content/GaussianSV_data_"+dataset+"/"+dtype+"/input_data_"+dataset+"_"+dtype+".txt \
      --word_vectors ./input_data/"+dataset+"/content/GaussianSV_data_"+dataset+"/"+dtype+"/unit_len_embeddings"+dataset+"_"+dtype+".txt \
      --num_topics "+num_topic+"\
      --output_file ./Output/"+dataset+"/"+dtype+"/output_"+dtype+"_topics_"+num_topic+"_runs_"+str(r+1)+".txt")
