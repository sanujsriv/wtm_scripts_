import os

## Small
os.chdir("/home/grad16/sakumar/CIKM_Experiments_2021/GaussianSV")
topics=[str(t) for t in range(10,60,10)]
datasets = ['bbc','searchsnippet','wos']
# dtypes=['full','short','small']
samples=5
no_of_runs = 5
for dataset in datasets:
  for num_topic in topics:
    for i in range(samples):
      for r in range(no_of_runs):
        os.system("perl gaussiansv.pl \
      --data ./input_data/"+dataset+"/content/GaussianSV_data_"+dataset+"/small/input_data_"+dataset+"_smallsample_"+str(i+1)+".txt \
      --word_vectors ./input_data/"+dataset+"/content/GaussianSV_data_"+dataset+"/small/unit_len_embeddings"+dataset+"_smallsample_"+str(i+1)+".txt \
      --num_topics "+num_topic+"\
      --output_file ./Output/"+dataset+"/small/output_small_sample_"+str(i+1)+"_topics_"+num_topic+"_runs_"+str(r+1)+".txt")
