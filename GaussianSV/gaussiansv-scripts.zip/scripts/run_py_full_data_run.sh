#!/bin/sh
python3 py_full_data_run.py
