#!/bin/sh
python3 py_small_data_run.py
