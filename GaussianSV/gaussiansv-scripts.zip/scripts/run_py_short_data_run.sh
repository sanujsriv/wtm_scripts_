#!/bin/sh
python3 py_short_data_run.py
